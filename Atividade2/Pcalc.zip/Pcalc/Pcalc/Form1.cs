﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; //globais 

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Btnsubtrair_Click(object sender, EventArgs e)
        {

            resultado = numero1 - numero2;
            txtresult.Text = resultado.ToString();
        }

        private void Txtnum1_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtnum1.Text, out numero1))
            {
                MessageBox.Show("Número Inválido!");
                txtnum1.Focus();
            }
        }

        private void Txtnum2_Validated(object sender, EventArgs e)
        {

            if (!Double.TryParse(txtnum2.Text, out numero2))
            {
                MessageBox.Show("Número Inválido!");
                txtnum1.Focus();
            }
        }

        private void Btnsomar_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtresult.Text = resultado.ToString();
        }

        private void Btndividir_Click(object sender, EventArgs e)
        {
            if(numero2 == 0)
            {
                MessageBox.Show("Não pode dividir por zero!!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtnum2.Focus();
            }
            else
            {

                resultado = numero1 / numero2;
                txtresult.Text = resultado.ToString();
            }
        }

        private void Btnsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void Btnmultiplicar_Click(object sender, EventArgs e)
        {

            resultado = numero1 * numero2;
            txtresult.Text = resultado.ToString();
        }

        private void Btnlimpar_Click(object sender, EventArgs e)
        {
            txtnum1.Clear();
            txtnum2.Clear();
            txtresult.Clear();
            txtnum1.Focus();
            resultado = 0;
            numero1 = 0;
            numero2 = 0;
        }
    }
}

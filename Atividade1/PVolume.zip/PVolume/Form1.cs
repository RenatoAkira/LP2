﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        double Raio, Altura, Volume; 
        public Form1()
        {
            InitializeComponent();
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out Altura))
            {
                MessageBox.Show("Altura inválida");
                txtAltura.Focus();
            }
            else
                if (Altura<=0)
            {
                MessageBox.Show("Altura deve ser maior que 0");
                txtAltura.Focus();
            }
            }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            Volume = Math.PI * Math.Pow(Raio, 2) * Altura;
            txtVolume.Text = Volume.ToString("N2");
        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void TxtRaio_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void TxtRaio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out Raio))
            {
                MessageBox.Show("Raio inválido");
                txtRaio.Focus();
            }
            else
            {
                if (Raio <= 0)
                {
                    MessageBox.Show("Raio não pode ser <=0");
                    txtRaio.Focus();
                }
            }
        }
    }
}

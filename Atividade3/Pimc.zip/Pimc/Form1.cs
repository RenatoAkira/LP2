﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void MaskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void MskbxPeso_Validated(object sender, EventArgs e)
        {
            double peso;
            errorProvider1.SetError(mskbxPeso, "");

            if (!double.TryParse(mskbxPeso.Text, out peso) || (peso <= 0))
            {
                MessageBox.Show("Peso inválido!");
                errorProvider1.SetError(mskbxPeso, "Peso inválido!");
            }
        }

        private void MskbxAltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

            double altura;
            errorProvider2.SetError(mskbxAltura, "");

            if (!double.TryParse(mskbxAltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("Altura inválida!");
                errorProvider2.SetError(mskbxAltura, "Altura inválida!");
            }
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            double pesoAtual, altura, imc;

            if(double.TryParse(mskbxAltura.Text, out altura) && 
                double.TryParse(mskbxPeso.Text, out pesoAtual))
            {
                if((altura <= 0) || (pesoAtual <= 0))
                    MessageBox.Show("Valores devem ser maiores que zero!");
                else
                {
                    imc = pesoAtual / (Math.Pow(altura, 2));
                    imc = Math.Round(imc, 1);
                    mskbxIMC.Text = imc.ToString("");

                    if (imc < 18.5)
                        mskbxIMC.Text += " Magreza";
                    else if (imc <= 24.9)
                        MessageBox.Show("Normal");
                    else if(imc <= 29.9)
                        MessageBox.Show("Sobrepeso");
                    else if(imc <= 39.9)
                        MessageBox.Show("Obesidade");
                    else
                        MessageBox.Show("Obesidade Grave");
                }
            }
        }

        private void MskbxPeso_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            mskbxIMC.Clear();

        }
    }
}

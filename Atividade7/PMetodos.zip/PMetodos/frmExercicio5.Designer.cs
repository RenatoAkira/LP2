﻿namespace PMetodos
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPrimeiro = new System.Windows.Forms.TextBox();
            this.txtSegundo = new System.Windows.Forms.TextBox();
            this.lvlPrimeironumero = new System.Windows.Forms.Label();
            this.lvlSegundonumero = new System.Windows.Forms.Label();
            this.btnSorteio = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtPrimeiro
            // 
            this.txtPrimeiro.Location = new System.Drawing.Point(216, 100);
            this.txtPrimeiro.Name = "txtPrimeiro";
            this.txtPrimeiro.Size = new System.Drawing.Size(207, 20);
            this.txtPrimeiro.TabIndex = 0;
            // 
            // txtSegundo
            // 
            this.txtSegundo.Location = new System.Drawing.Point(216, 184);
            this.txtSegundo.Name = "txtSegundo";
            this.txtSegundo.Size = new System.Drawing.Size(207, 20);
            this.txtSegundo.TabIndex = 1;
            // 
            // lvlPrimeironumero
            // 
            this.lvlPrimeironumero.AutoSize = true;
            this.lvlPrimeironumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvlPrimeironumero.Location = new System.Drawing.Point(41, 100);
            this.lvlPrimeironumero.Name = "lvlPrimeironumero";
            this.lvlPrimeironumero.Size = new System.Drawing.Size(126, 20);
            this.lvlPrimeironumero.TabIndex = 2;
            this.lvlPrimeironumero.Text = "Primeiro Número";
            // 
            // lvlSegundonumero
            // 
            this.lvlSegundonumero.AutoSize = true;
            this.lvlSegundonumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvlSegundonumero.Location = new System.Drawing.Point(41, 184);
            this.lvlSegundonumero.Name = "lvlSegundonumero";
            this.lvlSegundonumero.Size = new System.Drawing.Size(134, 20);
            this.lvlSegundonumero.TabIndex = 3;
            this.lvlSegundonumero.Text = "Segundo Número";
            // 
            // btnSorteio
            // 
            this.btnSorteio.Location = new System.Drawing.Point(216, 344);
            this.btnSorteio.Name = "btnSorteio";
            this.btnSorteio.Size = new System.Drawing.Size(134, 53);
            this.btnSorteio.TabIndex = 4;
            this.btnSorteio.Text = "Realizar Sorteio";
            this.btnSorteio.UseVisualStyleBackColor = true;
            this.btnSorteio.Click += new System.EventHandler(this.BtnSorteio_Click);
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 641);
            this.Controls.Add(this.btnSorteio);
            this.Controls.Add(this.lvlSegundonumero);
            this.Controls.Add(this.lvlPrimeironumero);
            this.Controls.Add(this.txtSegundo);
            this.Controls.Add(this.txtPrimeiro);
            this.Name = "frmExercicio5";
            this.Text = "frmExercicio5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPrimeiro;
        private System.Windows.Forms.TextBox txtSegundo;
        private System.Windows.Forms.Label lvlPrimeironumero;
        private System.Windows.Forms.Label lvlSegundonumero;
        private System.Windows.Forms.Button btnSorteio;
    }
}
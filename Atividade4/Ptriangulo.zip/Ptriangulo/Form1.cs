﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double valorA, valorB, valorC;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtValorA_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorB.Text, out valorB) || (valorB <= 0))
            {
                MessageBox.Show("Valor inválido!");
                txtValorB.Focus();
            }
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorA.Text, out valorA) || (valorA <= 0))
            {
                MessageBox.Show("Valor inválido!");
                txtValorA.Focus();
            }
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorC.Text, out valorC) || (valorC <= 0))
            {
                MessageBox.Show("Valor inválido!");
                txtValorC.Focus();
            }
        }

        private void txtTriangulo_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (valorA + valorB > valorC && valorA + valorC > valorB && valorB + valorC > valorA) 
            {
                if (valorA == valorB && valorB == valorC)
                {
                    txtTriangulo.Text += " Equilátero";
                }
                else if (valorA == valorB || valorA == valorC || valorB == valorC)
                {
                    txtTriangulo.Text += " Isósceles";
                }
                else
                {
                    txtTriangulo.Text += " Escaleno";
                }
            }
            else
            {
                MessageBox.Show("Não é possivel formar um triângulo com esses valores!!");
                txtValorA.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();
            txtTriangulo.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
